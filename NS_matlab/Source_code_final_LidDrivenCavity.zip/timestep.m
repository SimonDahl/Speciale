function dt=timestep(CFL,u,v,beta2,x,y,Re)
    lambda_x=(max(max(abs(u)))+sqrt(max(max(abs(u)))+beta2))/min(diff(x))+1/(Re*min(diff(x))^2);
    lambda_y=(max(max(abs(v)))+sqrt(max(max(abs(v)))+beta2))/min(diff(y))+1/(Re*min(diff(y))^2);
    
    dt=CFL/(lambda_x+lambda_y);
end