function [x] = JacobiGL(alpha,beta,N)
    x = zeros(1,N+1);
    x(1)=-1;x(end)=1;

    [xj,~] = JacobiGQ(alpha+1,beta+1,N-2);
    x(2:end-1) =xj;
end