function y=polyinterp(u,x,N,a,b)  %N=50  x=xref 10
    alpha=0;beta=0;
    [x_interp] = JacobiGL(alpha,beta,N);


    V=zeros(N+1);
    for k=0:N
        V(:,k+1)=JacobiP(x_interp,alpha,beta,k)';
    end

    h=zeros(N+1,length(x));
    for j=1:length(x)
        phi=zeros(N+1,1);
        for i=0:N
            [P]=JacobiP(x(j)*2/(b-a)-(a+b)/(b-a),alpha,beta,i);
            phi(i+1)=P;
        end
        h(:,j)=V'\phi;
    end
    y=sum(u.*h);
end