function [x,y,x0,y0]=grid1(Nx,Ny,xl,xr,yb,yt)
    x0=JacobiGL(0,0,Nx);
    y0=JacobiGL(0,0,Ny);
    
    x=x0*(xr-xl)/2+(xr+xl)/2;
    y=y0*(yt-yb)/2+(yt+yb)/2;
end