clc
clear
close all


Ulid=1;
beta=sqrt(5.0);
Re=1000;
counter=0;
CFL=2;
steadytol=1e-10;

xref=[0.0000 0.0312 0.0391 0.0469 0.0547 0.0937 0.1406 0.1953 0.5000 0.7656 0.7734 0.8437 0.9062 0.9219 0.9297 0.9375 1.0000];
vref=[0.0000000 -0.2279225 -0.2936869 -0.3553213 -0.4103754 -0.5264392 -0.4264545 -0.3202137 0.0257995 0.3253592 0.3339924 0.3769189 0.3330442 0.3099097 0.2962703 0.2807056 0.0000000];
pref1=[0.077455 0.078837 0.078685 0.078148 0.077154 0.065816 0.049029 0.034552 0.000000 0.044848 0.047260 0.069511 0.084386 0.086716 0.087653 0.088445 0.090477];
yref=[1.0000 0.9766 0.9688 0.9609 0.9531 0.8516 0.7344 0.6172 0.5000 0.4531 0.2813 0.1719 0.1016 0.0703 0.0625 0.0547 0.0000];
uref=[-1.0000000 -0.6644227 -0.5808359 -0.5169277 -0.4723329 -0.3372212 -0.1886747 -0.0570178 0.0620561 0.1081999 0.2803696 0.3885691 0.3004561 0.2228955 0.2023300 0.1812881 0.0000000];
pref2=[0.052987 0.052009 0.051514 0.050949 0.050329 0.034910 0.012122 -0.000827 0.000000 0.004434 0.040377 0.081925 0.104187 0.108566 0.109200 0.109689 0.110591];


N=50;
Nx=N;Ny=N;xl=-0.5;xr=0.5;yb=-0.5;yt=0.5;

P=zeros(Ny+1,Nx+1);dP=zeros(Ny+1,Nx+1);
U=zeros(Ny+1,Nx+1);dU=zeros(Ny+1,Nx+1);
V=zeros(Ny+1,Nx+1);dV=zeros(Ny+1,Nx+1);

U(Ny+1,3:end-2)=Ulid;U(Ny+1,2)=Ulid/2;U(Ny+1,end-1)=Ulid/2;
Umax=Ulid;
Vmax=0;

tstart=cputime;


[x,y,Dx,Dy,Laplace,Dxp,Dyp,Mx,My]=operators(Nx,Ny,xl,xr,yb,yt);
[X,Y]=meshgrid(x,y);

w=[1/4 1/3 1/2 1];
changeU=1;changeV=1;convergencehist=[];
while max(changeU,changeV) > steadytol 

    counter=counter+1;
    dt=timestep(CFL,U,V,beta^2,x,y,Re);

    Pold=P;
    Uold=U;
    Vold=V;

    for s=1:4

        dP(:)=-(beta^2)*Dx*U(:)-(beta^2)*Dy*V(:);
        dU(:)=-Dxp*P(:)+(1/Re*Laplace)*U(:)-(U(:).*(Dx*U(:))+V(:).*(Dy*U(:)));
        dV(:)=-Dyp*P(:)+(1/Re*Laplace)*V(:)-(U(:).*(Dx*V(:))+V(:).*(Dy*V(:)));

        P=Pold+w(s)*dt*dP;

        U(2:Ny,2:Nx)=Uold(2:Ny,2:Nx)+w(s)*dt*dU(2:Ny,2:Nx);
        V(2:Ny,2:Nx)=Vold(2:Ny,2:Nx)+w(s)*dt*dV(2:Ny,2:Nx);

    end

    dU=U - Uold;
    dV=V - Vold;

    changeU=norm(dU(:),2)/norm(Uold(:),2);
    changeV=norm(dV(:),2)/norm(Vold(:),2);

    max(changeU,changeV)
    convergencehist(counter)=max(changeU,changeV);


end

tend=cputime-tstart
figure(1)
streamslice(X,Y,U,V,6)
axis equal
axis off
box on

figure(2)
omega=zeros(Ny+1,Nx+1);
omega(:) =Dx*V(:)-Dy*U(:);
contourf(X,Y,omega,1000)
axis equal
axis off
box on

E=trapz(x,trapz(y,U.^2))/2;
Z=trapz(x,trapz(y,omega.^2))/2;
P=trapz(x,trapz(y,(Dxomega+Dyomega).^2))/2;