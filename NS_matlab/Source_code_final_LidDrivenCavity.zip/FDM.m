function D=FDM(N)
    x = (0:N-1)/N*2*pi;
    D=zeros(N);
    if mod(N,2)==1
        for k=0:N-1
            for j=0:N-1
                D(k+1,j+1)=(N*cos(0.5*N*(x(k+1)-x(j+1)))*sin(0.5*(x(k+1)-x(j+1)))-cos(0.5*(x(k+1)-x(j+1)))*sin(0.5*N*(x(k+1)-x(j+1))))/(2*N*(sin(0.5*(x(k+1)-x(j+1))))^2);
            end
        end
    else
        for k=0:N-1
            for j=0:N-1
                D(k+1,j+1)=(cos(0.5*N*(x(k+1)-x(j+1)))*cos(0.5*(x(k+1)-x(j+1))))/(2*sin(0.5*(x(k+1)-x(j+1))))-(sin(0.5*N*(x(k+1)-x(j+1))))/2/N-(sin(0.5*N*(x(k+1)-x(j+1)))*(cos(0.5*(x(k+1)-x(j+1))))^2)/(2*N*(sin(0.5*(x(k+1)-x(j+1))))^2);
            end
        end
    end
    D(isnan(D))=0;
end