function [P]=JacobiP(x,alpha,beta,n)
    P0=ones(size(x));
    P1=0.5*(alpha-beta+(alpha+beta+2)*x);
    if n==0
        P=P0;
    elseif n==1
        P=P1;
    else
        P_oldold=P0;P_old=P1;
        for i=1:n-1
            alpha1=2*(i+alpha)*(i+beta)/(2*i+alpha+beta+1)/(2*i+alpha+beta);
            alpha2=(alpha^2-beta^2)/(2*i+alpha+beta+2)/(2*i+alpha+beta);
            alpha3=2*(i+1)*(i+alpha+beta+1)/(2*i+alpha+beta+2)/(2*i+alpha+beta+1);
            
            P=((alpha2+x).*P_old-alpha1*P_oldold)/alpha3;
            P_oldold=P_old;P_old=P;
        end
    end
end

% function [P]=JacobiP(alpha,beta,n)
%     P0=@(x) 1+0*x;
%     P1=@(x) 0.5*(alpha-beta+(alpha+beta+2)*x);
%     if n==0
%         P=P0;
%     elseif n==1
%         P=P1;
%     else
%         P_oldold=P0;P_old=P1;
%         for i=1:n-1
%             alpha1=2*(i+alpha)*(i+beta)/(2*i+alpha+beta+1)/(2*i+alpha+beta);
%             alpha2=(alpha^2-beta^2)/(2*i+alpha+beta+2)/(2*i+alpha+beta);
%             alpha3=2*(i+1)*(i+alpha+beta+1)/(2*i+alpha+beta+2)/(2*i+alpha+beta+1);
%             
%             P=@(x)((alpha2+x).*P_old(x)-alpha1*P_oldold(x))/alpha3;
%             P_oldold=P_old;P_old=P;
%         end
%     end
% end


% function [P]=JacobiP(x,alpha,beta,n)
%     P0=ones(size(x));
%     P1=0.5*(alpha-beta+(alpha+beta+2)*x);
%     if n==0
%         P=P0;
%     elseif n==1
%         P=P1;
%     else
%         P_oldold=P0;P_old=P1;
%         for i=1:n-1
%             alpha1=2*(i+alpha)*(i+beta)/(2*i+alpha+beta+1)/(2*i+alpha+beta);
%             alpha2=(alpha^2-beta^2)/(2*i+alpha+beta+2)/(2*i+alpha+beta);
%             alpha3=2*(i+1)*(i+alpha+beta+1)/(2*i+alpha+beta+2)/(2*i+alpha+beta+1);
%             
%             P=((alpha2+x).*P_old-alpha1.*P_oldold)/alpha3;
%             P_oldold=P_old;P_old=P;
%         end
%     end
% end