function [x, y, Dx, Dy, Laplace, Dxp, Dyp, Mx, My] = operators(Nx, Ny, xl,xr,yb,yt)

dxdxi=(xr-xl)/2;dydxi=(yt-yb)/2;

[x,y,x0,y0]=grid1(Nx,Ny,xl,xr,yb,yt);

[Dx0,Mx0]=Diff_Matrix(Nx,x0,dxdxi);
[Dy0,My0]=Diff_Matrix(Ny,y0,dydxi);
Dx_pres=zeros(Nx+1);
Dx_pres(2:Nx,2:Nx)=Diff_Matrix(Nx-2,x0(2:Nx),dydxi);
Dy_pres=zeros(Ny+1);
Dy_pres(2:Ny,2:Ny)=Diff_Matrix(Ny-2,y0(2:Ny),dydxi);



Dx=kron(Dx0,speye(Ny+1));
Dy=kron(speye(Nx+1),Dy0);
Laplace=Dx*Dx+Dy*Dy;
Iy=sparse(Ny+1,Ny+1);Iy(2:Ny,2:Ny)=speye(Ny-1);
Dxp=kron(Dx_pres,Iy);
Ix=sparse(Nx+1,Nx+1);Ix(2:Nx,2:Nx)=speye(Nx-1);
Dyp=kron(Ix,Dy_pres);

Mx=Mx0*dxdxi;
My=My0*dydxi;
