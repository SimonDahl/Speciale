function [D,M]=Diff_Matrix(N,x,dxdxi)
    V=zeros(N+1);
    factor=zeros(N+1);
    factor1=zeros(N+1,1);
    for k=0:N
        V(:,k+1)=JacobiP(x,0,0,k)';
        factor(k+1,k+1)=(2/(2*k+1));
        factor1(k+1)=((2*k+1)/2);
    end
    
    
    Vx=zeros(N+1);
    Vx(:,1)=0;
    for k=1:N
        [dP]=GradJacobiP(x,0,0,k-1);
        dP=dP/dxdxi;
        Vx(:,k+1)=dP';
    end
    D=Vx*inv(V);
    M=inv(V*V');
end