function [P]=GradJacobiP(x,alpha,beta,n)
    [PP]=JacobiP(x,alpha+1,beta+1,n);
    P=(alpha+beta+n+2)/2*PP;
%     Vx=zeros(n+1);
%     for k=0:n
%         Vx(:,k+1)=dP';
%     end
end